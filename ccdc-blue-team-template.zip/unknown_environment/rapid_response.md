# Rapid Triage (Unknown Environment) — First 10 minutes

Goal: detect scope, preserve evidence, contain where possible, avoid changes that break forensics.

1) Info collection (0–3 min)
- Who reported it & how (console/syslog/alert)?
- Affected service(s) & observable symptoms (slow, new accounts, high CPU, exfil pattern).
- Note times in UTC and local.

2) Visibility: get network indicators (0–3 min)
- Query network devices / IDS for recent alerts (timestamps, src/dst IPs, ports).
- If you have a mirror/tap: start packet capture on suspected VLAN or IP:
  `tcpdump -i <tap> host <ip> -w /tmp/sus.pcap`
- If no tap, request switch SPAN or firewall logs immediately.

3) Host triage (0–5 min) — agentless preferred
- Ask remote admin to run (or run from jump host) the platform-appropriate probe (see `agentless/` scripts).
- Collect: running processes, network connections, active users, scheduled tasks/services, last logins, authentication failures.

4) Containment (5–10 min)
- If attacker IPs are known and you control edge ACLs, block at the firewall.
- If you do NOT control perimeter: request immediate ACL on switch or ephemeral disable of suspicious accounts.
- Do NOT reboot suspected hosts unless necessary.

5) Evidence & escalation
- Copy logs (syslog, application, firewall) to your secure server.
- Create an incident ticket with time, scope, indicators (IPs/hashes).
- If lateral movement suspected, isolate VLAN(s) and preserve backups.

Notes:
- Prefer read-only commands and log collection. Avoid changing configurations unless to block an active exfil stream and only after documenting.
