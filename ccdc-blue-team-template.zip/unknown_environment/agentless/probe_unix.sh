#!/usr/bin/env bash
OUTDIR="/tmp/probe-$(hostname)-$(date +%s)"
mkdir -p "$OUTDIR"
echo "Saving to $OUTDIR"

uname -a > $OUTDIR/uname.txt
whoami > $OUTDIR/whoami.txt
uptime > $OUTDIR/uptime.txt
ps aux --sort=-%cpu | head -n 30 > $OUTDIR/ps_top.txt
ss -tunap > $OUTDIR/ss.txt
netstat -anp 2>/dev/null | head -n 200 > $OUTDIR/netstat.txt
last -n 50 > $OUTDIR/last.txt
grep -i "failed password" /var/log/auth.log 2>/dev/null | tail -n 200 > $OUTDIR/auth_failed.txt || true
crontab -l 2>/dev/null > $OUTDIR/crontab.txt
ls -la /etc/cron* > $OUTDIR/cron_dirs.txt
find /tmp -type f -mtime -2 -ls > $OUTDIR/tmp_recent.txt
if [ -f /etc/passwd ]; then md5sum /etc/passwd > $OUTDIR/etc_passwd.md5; fi
if [ -f /etc/shadow ]; then ls -l /etc/shadow > $OUTDIR/etc_shadow.stat; fi
tar czf /tmp/probe-$(hostname)-snapshot.tgz -C /tmp "$(basename "$OUTDIR")"
echo "Snapshot at /tmp/probe-$(hostname)-snapshot.tgz"
