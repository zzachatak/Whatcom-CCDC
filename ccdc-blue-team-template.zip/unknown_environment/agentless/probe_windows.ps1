# probe_windows.ps1 — quick snapshot
$ts = Get-Date -Format s
$out = "C:\Windows\Temp\probe-$env:COMPUTERNAME-$ts"
New-Item -Path $out -ItemType Directory -Force | Out-Null

whoami > "$out\whoami.txt"
hostname > "$out\hostname.txt"
Get-Process | Sort-Object CPU -Descending | Select-Object -First 50 | Out-File "$out\processes.txt"
Get-NetTCPConnection | Out-File "$out\netconns.txt"
qwinsta | Out-File "$out\sessions.txt"
Get-LocalUser | Select Name,Enabled,LastLogon | Out-File "$out\localusers.txt"
Get-EventLog -LogName Security -Newest 200 | Out-File "$out\security_events.txt"
schtasks /query /fo LIST /v > "$out\schtasks.txt"
Get-Service | Where-Object {$_.StartType -eq "Automatic"} | Out-File "$out\auto_services.txt"

Compress-Archive -Path $out -DestinationPath "C:\Windows\Temp\probe-$env:COMPUTERNAME-$ts.zip" -Force
Write-Output "Snapshot: C:\Windows\Temp\probe-$env:COMPUTERNAME-$ts.zip"
