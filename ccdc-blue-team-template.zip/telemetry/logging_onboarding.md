# Telemetry Onboarding (Unknown Environments)

Preferred collection order:
1) Firewall/Router/Switch logs (syslog).
2) IDS/TAP (Suricata/Zeek) PCAPs + alerts for SMB/RDP/WinRM.
3) Mail/Proxy logs.
4) Host logs via remote export (EVTX/syslog).

Minimum fields: time (ISO8601), src_ip, dst_ip, src_port, dst_port, protocol, username, event_type, process (if available).

If limited: prioritize egress firewall/proxy logs.
