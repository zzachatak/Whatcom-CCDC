# CCDC Blue Team Template

Centralized repository for CCDC competitions: **hardening**, **detections**, **agentless triage**, **telemetry**, and **playbooks**.

## Structure
- `hardening/` — platform-agnostic hardening guides and automation
- `detections/` — IDS/SIEM rules & dashboards
- `unknown_environment/` — rapid triage + agentless probes (when you can't install agents)
- `telemetry/` — logging onboarding & ingestion examples
- `playbooks/` — incident runbooks and escalation
- `.github/` — issue/PR templates and CI
- `tools/` — helper utilities
- `references/` — ATT&CK mappings, quick matrices

## Quick Start
1. Read `unknown_environment/rapid_response.md`.
2. Use probes under `unknown_environment/agentless/` to collect host snapshots.
3. Load detection rules in `detections/` (Snort/Suricata/Sigma).
4. Apply baseline hardening (`hardening/scripts/*.sh`, `*.ps1`) where permitted.
5. Centralize logs per `telemetry/logging_onboarding.md`.
