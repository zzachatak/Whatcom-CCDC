---
name: Incident report
about: Use this to capture an incident during CCDC
title: "[INCIDENT] short summary"
labels: incident
---

## Summary
- Time (UTC/local):
- Reporter:
- Impacted hosts/services:

## Indicators
- Source IP(s): 
- Dest IP(s): 
- Ports/Protocols:
- Hashes/Files:

## Actions taken
- Containment:
- Eradication:
- Recovery:

## Next steps
- [ ] Lessons learned
- [ ] Update detections
- [ ] Add playbook items
