#!/usr/bin/env bash
set -euo pipefail

# Update & upgrade
apt update && apt -y upgrade

# Install basics
apt -y install unattended-upgrades auditd fail2ban ufw

# Sysctl safe defaults
declare -A SYSCTL=(
  ["net.ipv4.ip_forward"]="0"
  ["net.ipv4.conf.all.send_redirects"]="0"
  ["net.ipv4.conf.default.accept_redirects"]="0"
)
for k in "${!SYSCTL[@]}"; do
  sysctl -w "$k=${SYSCTL[$k]}"
  if grep -q "^$k" /etc/sysctl.conf; then
    sed -i "s|^$k.*|$k = ${SYSCTL[$k]}|" /etc/sysctl.conf
  else
    echo "$k = ${SYSCTL[$k]}" >> /etc/sysctl.conf
  fi
done

# UFW baseline
ufw default deny incoming
ufw default allow outgoing
ufw allow 22
yes | ufw enable

# Fail2ban minimal SSH jail
cat >/etc/fail2ban/jail.d/ssh.local <<'EOF'
[sshd]
enabled = true
maxretry = 5
bantime = 3600
EOF
systemctl restart fail2ban

echo "Ubuntu baseline applied."
