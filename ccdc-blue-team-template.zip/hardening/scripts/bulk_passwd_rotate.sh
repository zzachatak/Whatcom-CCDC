#!/usr/bin/env bash
#
# bulk_passwd_rotate.sh
# Rotate passwords for local users on Linux.
#
# Modes:
#  1) Provide a file with usernames (one per line) via -f <file>.
#  2) Auto-select human users: UID >= 1000 (excluding nologin/false shells) with -a.
#
# Output: CSV with username,new_password written to /root/cred-rotations-YYYYmmdd-HHMMSS.csv (chmod 0400).
#
# Usage examples:
#   sudo ./bulk_passwd_rotate.sh -f users.txt
#   sudo ./bulk_passwd_rotate.sh -a
#
set -euo pipefail

if [[ $EUID -ne 0 ]]; then
  echo "Run as root." >&2
  exit 1
fi

USERS=()
MODE=""
LIST_FILE=""
while getopts ":af:" opt; do
  case "$opt" in
    a) MODE="auto" ;;
    f) MODE="file"; LIST_FILE="$OPTARG" ;;
    *) echo "Usage: $0 [-a] [-f user_file]" ; exit 1 ;;
  esac
done

if [[ -z "${MODE}" ]]; then
  echo "Choose -a (auto) or -f <file>." >&2
  exit 1
fi

if [[ "${MODE}" == "file" ]]; then
  if [[ ! -f "$LIST_FILE" ]]; then
    echo "User file not found: $LIST_FILE" >&2
    exit 1
  fi
  mapfile -t USERS < <(grep -vE '^\s*(#|$)' "$LIST_FILE" | awk '{print $1}')
else
  # auto mode: UID >= 1000, shell not nologin/false
  USERS=($(awk -F: '($3>=1000)&&($7!="/usr/sbin/nologin")&&($7!="/bin/false"){print $1}' /etc/passwd))
fi

timestamp=$(date +%Y%m%d-%H%M%S)
out="/root/cred-rotations-$timestamp.csv"
touch "$out"
chmod 0400 "$out"

gen_pw() {
  # 20-char mixed password (A-Za-z0-9 + symbols)
  tr -dc 'A-Za-z0-9!@#$%^&*()-_=+[]{}' </dev/urandom | head -c 20
}

changed=0
for u in "${USERS[@]}"; do
  if id "$u" &>/dev/null; then
    pw=$(gen_pw)
    echo "${u}:${pw}" | chpasswd
    echo "$u,$pw" >> "$out"
    ((changed++))
    echo "Rotated: $u"
  else
    echo "Skip (no such user): $u" >&2
  fi
done

echo "Wrote CSV to $out (mode 0400). Rotated $changed account(s)."
echo "IMPORTANT: Securely deliver passwords and rotate again after competition if needed."
