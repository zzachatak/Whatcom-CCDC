# Requires elevated PowerShell
Set-NetFirewallProfile -Profile Domain,Private,Public -Enabled True

# Disable LM/NTLMv1
New-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name "LmCompatibilityLevel" -PropertyType DWord -Value 5 -Force | Out-Null

# Audit policy
auditpol /set /subcategory:"Logon" /success:enable /failure:enable
auditpol /set /subcategory:"Account Logon" /success:enable /failure:enable

# RDP NLA required
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp" -Name "UserAuthentication" -Value 1

Write-Host "Windows baseline applied."
